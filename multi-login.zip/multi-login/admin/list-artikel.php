<?php
defined('__NOT_DIRECT') || define('__NOT_DIRECT',1);
include '../cek-akses.php'; 
?>
<table width="900">
	<tr>
		<td valign="top">
			<?php include 'menu.php';?>
		</td>
		<td valign="top">
			<h2>List Artikel</h2>
		</td>
	</tr>
</table>
 
 
