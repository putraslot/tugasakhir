<?php
$__akses_config = array(
	'login.php',
	'logout.php',
	'register.php',
	'index.php',
	'view-artikel.php'
); 
