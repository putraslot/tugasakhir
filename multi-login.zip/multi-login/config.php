<?php
if(!defined('__NOT_DIRECT')){
	//mencegah akses langsung ke file ini
	die('Akses langsung tidak diizinkan!');
}

define('BASE_URL', '/tutorial/multi-login/'); 
//koneksi database
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS', 'blah');
define('DB_NAME' ,'test');
