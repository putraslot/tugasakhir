<?php
defined('__NOT_DIRECT') || define('__NOT_DIRECT',1);
include 'cek-akses.php';
if($_POST){
	mysql_connect(DB_HOST,DB_USER,DB_PASS);
	mysql_select_db(DB_NAME);
	$userId = mysql_real_escape_string($_POST['user_id']);
	$data = mysql_fetch_array(mysql_query("select * from user where user_id='".$userId."'"));
	if($data !== false && $data['password'] == md5($_POST['password'])){
		//login berhasil
		$_SESSION['tipe_user'] = $data['type'];
		$_SESSION['user_id'] = $data['user_id'];
		$_SESSION['my_user_agent'] = md5($_SERVER['HTTP_USER_AGENT']);
		header("Location: admin/index.php");
	}else{
		echo "ID User atau password salah!";
	}
}
?>
<form method="post" action="">
ID User: <input type="text" name="user_id"/>
Password: <input type="password" name="password"/>
<input type="submit" value="Login"/>
</form> 
