<ul>
	<li><a href="list-user.php">List User</a></li>
	<li><a href="add-user.php">Add User</a></li>
	<li><a href="list-artikel.php">List Artikel</a></li>
	<li><a href="add-artikel.php">Add Artikel</a></li>
	<li><a href="../logout.php">Logout</a></li>
</ul> 
