<?php
$__akses_config = array(
	'login.php',
	'logout.php',
	'admin/index.php',
	'admin/list-user.php',
	'admin/add-user.php',
	'admin/edit-user.php',
	'admin/delete-user.php',
	'admin/add-artikel.php',
	'admin/edit-artikel.php',
	'admin/list-artikel.php',
	'admin/delete-artikel.php',
	'index.php',
	'view-artikel.php'
);
