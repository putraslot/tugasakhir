CREATE  TABLE `test`.`user` (
  `user_id` VARCHAR(40) NOT NULL ,
  `name` VARCHAR(50) NULL ,
  `password` VARCHAR(50) NULL ,
  `type` VARCHAR(20) NULL ,
  PRIMARY KEY (`user_id`) )
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;
 
